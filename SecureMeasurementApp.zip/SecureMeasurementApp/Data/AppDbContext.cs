using Microsoft.EntityFrameworkCore;
using SecureMeasurementApp.Models;

namespace SecureMeasurementApp.Data
{
    /// <summary>
    /// Entity Framework Core database context.
    /// All database operations use parameterized queries to prevent SQL injection.
    /// </summary>
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Measurement> Measurements { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Measurement>().ToTable("MEASUREMENT");

            modelBuilder.Entity<Measurement>().HasData(
                new Measurement { MeasurementId = 1, MeasurementName = "Temperature", MeasurementUnit = "°C" },
                new Measurement { MeasurementId = 2, MeasurementName = "Pressure",    MeasurementUnit = "bar" },
                new Measurement { MeasurementId = 3, MeasurementName = "Humidity",    MeasurementUnit = "%" },
                new Measurement { MeasurementId = 4, MeasurementName = "Voltage",     MeasurementUnit = "V" }
            );
        }
    }
}
