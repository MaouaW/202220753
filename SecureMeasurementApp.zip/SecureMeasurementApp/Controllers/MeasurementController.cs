using Ganss.Xss;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SecureMeasurementApp.Data;
using SecureMeasurementApp.Models;

namespace SecureMeasurementApp.Controllers
{
    /// <summary>
    /// MVC Controller for Measurement CRUD operations.
    /// Implements SQL Injection protection via EF Core, XSS prevention via HtmlSanitizer,
    /// CSRF validation, over-posting protection with whitelists, and model validation.
    /// </summary>
    public class MeasurementController : Controller
    {
        private readonly AppDbContext _db;
        private readonly HtmlSanitizer _sanitizer;

        public MeasurementController(AppDbContext db)
        {
            _db = db;
            _sanitizer = new HtmlSanitizer();
            _sanitizer.AllowedTags.Clear();
            _sanitizer.AllowedAttributes.Clear();
        }

        public async Task<IActionResult> Index()
        {
            var list = await _db.Measurements
                                .AsNoTracking()
                                .OrderBy(m => m.MeasurementName)
                                .ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id is null) return BadRequest();

            var measurement = await _db.Measurements
                                       .AsNoTracking()
                                       .FirstOrDefaultAsync(m => m.MeasurementId == id);

            if (measurement is null) return NotFound();
            return View(measurement);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MeasurementName,MeasurementUnit")] Measurement measurement)
        {
            if (!ModelState.IsValid) return View(measurement);

            measurement.MeasurementName = _sanitizer.Sanitize(measurement.MeasurementName);
            measurement.MeasurementUnit = _sanitizer.Sanitize(measurement.MeasurementUnit);

            _db.Measurements.Add(measurement);
            await _db.SaveChangesAsync();

            TempData["SuccessMessage"] = "Measurement created successfully.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id is null) return BadRequest();

            var measurement = await _db.Measurements.FindAsync(id);
            if (measurement is null) return NotFound();

            return View(measurement);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MeasurementId,MeasurementName,MeasurementUnit")] Measurement measurement)
        {
            if (id != measurement.MeasurementId) return BadRequest();
            if (!ModelState.IsValid) return View(measurement);

            measurement.MeasurementName = _sanitizer.Sanitize(measurement.MeasurementName);
            measurement.MeasurementUnit = _sanitizer.Sanitize(measurement.MeasurementUnit);

            try
            {
                _db.Measurements.Update(measurement);
                await _db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!await _db.Measurements.AnyAsync(m => m.MeasurementId == id))
                    return NotFound();
                throw;
            }

            TempData["SuccessMessage"] = "Measurement updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id is null) return BadRequest();

            var measurement = await _db.Measurements
                                       .AsNoTracking()
                                       .FirstOrDefaultAsync(m => m.MeasurementId == id);
            if (measurement is null) return NotFound();

            return View(measurement);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var measurement = await _db.Measurements.FindAsync(id);
            if (measurement is not null)
            {
                _db.Measurements.Remove(measurement);
                await _db.SaveChangesAsync();
            }

            TempData["SuccessMessage"] = "Measurement deleted.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Search(string? term)
        {
            ViewBag.Term = term;

            if (string.IsNullOrWhiteSpace(term))
                return View(new List<Measurement>());

            var results = await _db.Measurements
                                   .AsNoTracking()
                                   .Where(m => m.MeasurementName.Contains(term)
                                            || m.MeasurementUnit.Contains(term))
                                   .OrderBy(m => m.MeasurementName)
                                   .ToListAsync();
            return View(results);
        }
    }
}
