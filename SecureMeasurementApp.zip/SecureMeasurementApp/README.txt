Note:I have copied and edited existing project from online existing examples.

Secure Measurement App
ASP.NET Core 8 MVC + Entity Framework Core SQLite
SQL Injection & XSS Protection - Course Project Documentation

================================================================================
1. PROJECT DESCRIPTION
================================================================================
This web application is an upgraded, secure implementation of the measurement
management system. It replaces insecure practices such as raw SQL string 
concatenation and un-encoded user input display with modern, secure enterprise 
development patterns.

================================================================================
2. COMPARATIVE SECURITY ANALYSIS
================================================================================
Feature              Insecure Code (Vulnerable Example)   Secure Implementation
--------------------------------------------------------------------------------
Architecture         Single-file or basic Razor Pages     Model-View-Controller (MVC)
Database Access      Raw SQLite commands & string SQL     Entity Framework Core
SQL Injection        Vulnerable (string concatenation)    EF Parameterized queries
XSS (Stored)         No input sanitization                HtmlSanitizer on save
XSS (Reflected)      No output encoding                   Razor engine Auto-encoding
CSRF Protection      No tokens/verification               [ValidateAntiForgeryToken]
Over-Posting Guard   No validation parameters             [Bind] whitelist filter
Input Validation     None                                 Data Annotations & Regex
Security Headers     None                                 CSP, HSTS, X-Frame-Options
================================================================================

================================================================================
3. DETAILED SECURITY MEASURES
================================================================================

1. SQL INJECTION (SQLi) PROTECTION
- Problem in insecure code:
  User input is appended directly to the SQL query:
  "SELECT * FROM MEASUREMENT WHERE Name = '" + userInput + "'"
  If userInput is: "' OR '1'='1"
  The query compiles as:
  "SELECT * FROM MEASUREMENT WHERE Name = '' OR '1'='1'"
  This bypasses logical checks and leaks unauthorized data. If the input contains
  statements like "'; DROP TABLE MEASUREMENT;--", the database can be destroyed.

- Protection in this project:
  All database queries are executed via Entity Framework Core. For example, in
  MeasurementController.cs:
  _db.Measurements.Where(m => m.MeasurementName.Contains(term))
  EF Core translates this into:
  "SELECT * FROM MEASUREMENT WHERE MeasurementName LIKE @p0"
  The database engine treats the contents of @p0 strictly as a parameter value,
  never as executable SQL commands. This eliminates SQL injection entirely.

2. CROSS-SITE SCRIPTING (XSS) PROTECTION
- Problem in insecure code:
  If a user submits a string like "<script>alert('XSS')</script>" and the 
  application stores it directly and displays it back to other users without
  modification, the browser executes the script in the context of the user's
  session, potentially stealing session cookies.

- Protection in this project:
  This application uses a multi-layered defense-in-depth approach:
  * Layer 1 (Sanitization):
    Before saving the record to the database, Ganss HtmlSanitizer is called 
    to remove all HTML tags:
    measurement.MeasurementName = _sanitizer.Sanitize(measurement.MeasurementName);
  * Layer 2 (Output Encoding):
    The Razor view engine (@model or @item.MeasurementName) automatically HTML-encodes 
    special characters before writing them to the response.
    "<script>alert(1)</script>" is rendered as "&lt;script&gt;alert(1)&lt;/script&gt;"
    The browser displays it harmlessly as plain text.

3. CROSS-SITE REQUEST FORGERY (CSRF) PROTECTION
- Problem in insecure code:
  A third-party malicious website could issue a request to the application,
  such as POSTing to "/Measurement/Delete/5", while a user is authenticated. 
  The browser would automatically attach the authenticated session cookie,
  resulting in unauthorized data deletion.

- Protection in this project:
  All forms use MVC tag helpers which automatically inject a unique, cryptographically
  secure token:
  <input type="hidden" name="__RequestVerificationToken" value="..." />
  The Controller verifies this token on POST requests using:
  [ValidateAntiForgeryToken]
  Requests originating from external domains are rejected with HTTP 400 Bad Request.

4. OVER-POSTING PROTECTION
- Problem in insecure code:
  When receiving a model directly from a form, an attacker could inject additional
  properties in the HTTP request body (e.g. modified primary keys or audit fields)
  which the server model-binder maps and updates, overwriting database records.

- Protection in this project:
  The Controller restricts binding using the [Bind] attribute:
  [Bind("MeasurementName,MeasurementUnit")]
  Properties not in the whitelist are ignored during model binding.

5. INPUT VALIDATION
- Model data annotations in Models/Measurement.cs restrict valid characters, 
  lengths, and required states.
  The regular expression [RegularExpression(@"^[a-zA-Z0-9\s\-_.,()]+$")] ensures
  that only safe printable characters are accepted, blocking character sequences
  common to exploit payloads before the server processes the request.

6. HTTP SECURITY HEADERS
- In Program.cs, middleware applies security headers on every response:
  * Content-Security-Policy (CSP): Restricts source domains for scripts, styles,
    and fonts, preventing inline injection execution.
  * X-Content-Type-Options: Set to "nosniff" to block MIME-type sniffing attacks.
  * X-Frame-Options: Set to "DENY" to prevent clickjacking in iframes.

================================================================================
4. PROJECT DIRECTORY STRUCTURE
================================================================================
SecureMeasurementApp/
├── Controllers/
│   └── MeasurementController.cs   - Action methods and sanitization logic
├── Data/
│   └── AppDbContext.cs            - EF Core configuration and database seeding
├── Models/
│   └── Measurement.cs             - Entity model with validation annotations
├── Views/
│   ├── Measurement/
│   │   ├── Index.cshtml           - Measurement listing view
│   │   ├── Create.cshtml          - Creation form view with CSRF protection
│   │   ├── Edit.cshtml            - Update form view
│   │   ├── Delete.cshtml          - Deletion confirmation view
│   │   ├── Details.cshtml         - Detailed view for a single measurement
│   │   └── Search.cshtml          - Parameterized search page
│   ├── Shared/
│   │   ├── _Layout.cshtml         - Master page template with CSS links
│   │   └── _ValidationScriptsPartial.cshtml - Client-side validation scripts
│   ├── _ViewImports.cshtml        - Assembly reference imports for views
│   └── _ViewStart.cshtml          - Global layout pointer
├── wwwroot/
│   └── css/
│       └── site.css               - CSS styles (glassmorphism details)
├── Program.cs                     - Application bootstrapper and middleware
├── appsettings.json               - Database connection string configuration
└── SecureMeasurementApp.csproj    - Project file with NuGet dependencies

================================================================================
5. HOW TO RUN THE APPLICATION
================================================================================
Prerequisites:
- .NET 8.0 SDK or higher installed on the system.

Steps to Run:
1. Open a command prompt or terminal in the "SecureMeasurementApp" directory.
2. Restore NuGet dependencies:
   dotnet restore
3. Run the application:
   dotnet run
4. Open a web browser and navigate to:
   http://localhost:5000 or https://localhost:5001
5. The application database ("MEASUREMENTDB.db") is created and seeded
   automatically on the first execution. No manual migrations are required.
