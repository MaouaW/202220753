using System.ComponentModel.DataAnnotations;

namespace SecureMeasurementApp.Models
{
    /// <summary>
    /// Entity mapped by EF Core to the MEASUREMENT table.
    /// Data annotations enforce input validation as a first line of defense
    /// against both SQL Injection and XSS (via regular expression validation).
    /// </summary>
    public class Measurement
    {
        [Key]
        public int MeasurementId { get; set; }

        [Required(ErrorMessage = "Measurement name is required.")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Name must be between 1 and 100 characters.")]
        [RegularExpression(@"^[a-zA-Z0-9\s\-_.,()]+$", ErrorMessage = "Name contains invalid characters.")]
        [Display(Name = "Measurement Name")]
        public string MeasurementName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Unit is required.")]
        [StringLength(20, MinimumLength = 1, ErrorMessage = "Unit must be between 1 and 20 characters.")]
        [RegularExpression(@"^[a-zA-Z0-9°/%µ²³\-]+$", ErrorMessage = "Unit contains invalid characters.")]
        [Display(Name = "Unit")]
        public string MeasurementUnit { get; set; } = string.Empty;
    }
}
